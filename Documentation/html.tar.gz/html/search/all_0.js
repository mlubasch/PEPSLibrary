var searchData=
[
  ['add',['add',['../classMatrix.html#a64b85a918d2554b9151cd124413c4898',1,'Matrix::add()'],['../classTensor.html#a6779b55eedfebe1f39835dac31ac1b67',1,'Tensor::add()']]],
  ['adjoint',['adjoint',['../classMatrix.html#a44e9551203e5f92f77c7c57f03f1af18',1,'Matrix::adjoint()'],['../classMatrix.html#a9758dd83fd604acdee292e0c33e21db9',1,'Matrix::adjoint(Matrix&lt; T &gt; &amp;Matrix0) const '],['../classMPO.html#a9f4d569c610f546e2fee315d5b5374ae',1,'MPO::adjoint()']]],
  ['approximate',['approximate',['../classMPS.html#aaa511dadb82a478dee422c2fad4793c9',1,'MPS']]]
];
