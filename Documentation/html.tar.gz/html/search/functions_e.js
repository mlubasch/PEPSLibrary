var searchData=
[
  ['qrdecompose',['QRDecompose',['../classMatrix.html#a378c66361c76749188757c1b0be8912d',1,'Matrix::QRDecompose()'],['../classTensor.html#a7d5878dc4616b7c133b364abbfd9a4fe',1,'Tensor::QRDecompose()']]]
];
