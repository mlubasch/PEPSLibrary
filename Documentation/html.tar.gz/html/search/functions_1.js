var searchData=
[
  ['bosehubbardmodel',['BoseHubbardModel',['../classBoseHubbardModel.html#aeebc508e0401aa7f59e8e1dc6e2556fa',1,'BoseHubbardModel::BoseHubbardModel()'],['../classBoseHubbardModel.html#a8efeb8f440c1d0a47cf3c1283bc68544',1,'BoseHubbardModel::BoseHubbardModel(const string &amp;BC0, unsigned int N0, unsigned int d0, const vector&lt; T &gt; &amp;Parameters0)'],['../classBoseHubbardModel.html#a6970132de85071afacf0f79682961520',1,'BoseHubbardModel::BoseHubbardModel(const string &amp;BC0, unsigned int N0, unsigned int d0, const vector&lt; PointerToFunction &gt; &amp;TimeFunctions0, double time0)'],['../classBoseHubbardModel.html#a5e5371893ffe9b787ace70688da662f8',1,'BoseHubbardModel::BoseHubbardModel(const BoseHubbardModel&lt; T &gt; &amp;BoseHubbardModel0)']]],
  ['bringintonormalform',['bringIntoNormalForm',['../classMPS.html#a6f065482af92acea9a653c39ee4dfd24',1,'MPS']]],
  ['bringintonormalshape',['bringIntoNormalShape',['../classMPS.html#a6db412cc7f16976a8ab2602869dab29e',1,'MPS']]]
];
