var searchData=
[
  ['elements',['Elements',['../classTensor.html#aaa2b41efce92c9acca8612778c3366e1',1,'Tensor']]]
];
