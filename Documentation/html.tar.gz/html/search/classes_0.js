var searchData=
[
  ['bosehubbardmodel',['BoseHubbardModel',['../classBoseHubbardModel.html',1,'']]]
];
