var searchData=
[
  ['spinlesscoulombmodel',['SpinlessCoulombModel',['../classSpinlessCoulombModel.html',1,'']]],
  ['spinlessfermions',['SpinlessFermions',['../classSpinlessFermions.html',1,'']]]
];
