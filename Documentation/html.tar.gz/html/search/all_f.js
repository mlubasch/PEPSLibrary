var searchData=
[
  ['rank',['rank',['../classTensor.html#a4fb7542a9e054e86ff03899cc8b52290',1,'Tensor']]],
  ['read',['read',['../classMPS.html#af445659a5721987ddea89dd855b24083',1,'MPS::read()'],['../classPEPO.html#aad6966ecce3716e1e3ba80bf3d28a209',1,'PEPO::read()'],['../classPEPS.html#ab4eed36852b74812e84484d52e4ab320',1,'PEPS::read()'],['../classTensor.html#afb8e24def6e33a88080bbe3ff13aefe8',1,'Tensor::read()']]],
  ['readvalentinpeps',['readValentinPEPS',['../classPEPS.html#ab468aad70023f29b3e168eb378f0d7fc',1,'PEPS']]],
  ['reference',['reference',['../classGroundState.html#a705cabe27d04c1faad3cad5893ce7485',1,'GroundState::reference()'],['../classGroundState2D.html#a336a91abf714bbb1cfde5ce3d1a52a54',1,'GroundState2D::reference()'],['../classTimeEvolution.html#a605facb38e82c64016226e9317e06f57',1,'TimeEvolution::reference()'],['../classTimeEvolution2D.html#a634e627739e66e867d4221c8839da097',1,'TimeEvolution2D::reference()']]],
  ['representation',['Representation',['../classOperator.html#a0311bff179d27e8e5abb01e9e26f4f56',1,'Operator::Representation()'],['../classOperator2D.html#a026c1c0c62a7e1f72305f35a24d7a0de',1,'Operator2D::Representation()']]],
  ['reshape',['reshape',['../classTensor.html#a894546742cee1c1470dfd6af84748fc9',1,'Tensor']]]
];
