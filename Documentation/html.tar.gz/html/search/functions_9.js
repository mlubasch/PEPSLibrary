var searchData=
[
  ['linearleastsquares',['linearLeastSquares',['../classMatrix.html#ab6f1fda6d86ef0c5616ec4d77989c050',1,'Matrix']]],
  ['lqdecompose',['LQDecompose',['../classTensor.html#acea62da36b9f0c7f3acfe6f4fdd8500a',1,'Tensor']]]
];
