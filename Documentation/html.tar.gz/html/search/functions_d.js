var searchData=
[
  ['pepo',['PEPO',['../classPEPO.html#adb6709bc5777b03b0589a84d2f44bf65',1,'PEPO::PEPO()'],['../classPEPO.html#acad71d5472082b6e21ff97a1e817c124',1,'PEPO::PEPO(const string &amp;BC0, unsigned int Nrows, unsigned int Ncols, const Matrix&lt; unsigned int &gt; &amp;d0, unsigned int D0)'],['../classPEPO.html#a24c17b418f6b4eeca22fe14e83212820',1,'PEPO::PEPO(const string &amp;BC0, unsigned int Nrows, unsigned int Ncols, unsigned int d0, unsigned int D0)'],['../classPEPO.html#af448f5ec0d461653b8e31309404543ba',1,'PEPO::PEPO(const PEPO&lt; T &gt; &amp;PEPO0)']]],
  ['peps',['PEPS',['../classPEPS.html#ab70d2a93ef874f34a7da8d178505baee',1,'PEPS::PEPS()'],['../classPEPS.html#a19ba07b0b643291f0fe027686c0585ae',1,'PEPS::PEPS(const string &amp;BC0, unsigned int Nrows, unsigned int Ncols, const Matrix&lt; unsigned int &gt; &amp;d0, unsigned int D0)'],['../classPEPS.html#ad1b2524820afcbec7d1a6520ab4834a3',1,'PEPS::PEPS(const string &amp;BC0, unsigned int Nrows, unsigned int Ncols, unsigned int d0, unsigned int D0)'],['../classPEPS.html#a553263d275dcb17e3434dabf2628b6ee',1,'PEPS::PEPS(const PEPS&lt; T &gt; &amp;PEPS0)']]],
  ['permute',['permute',['../classTensor.html#ae20c863d361f1bb4479d08e2df37b82a',1,'Tensor']]],
  ['pseudoinvert',['pseudoinvert',['../classMatrix.html#a8d9e5582f0242eb03dff46761e281ca9',1,'Matrix']]]
];
