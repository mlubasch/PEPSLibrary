var searchData=
[
  ['isingmodel',['IsingModel',['../classIsingModel.html',1,'']]],
  ['isingmodel2d',['IsingModel2D',['../classIsingModel2D.html',1,'']]]
];
