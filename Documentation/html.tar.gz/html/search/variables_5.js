var searchData=
[
  ['rank',['rank',['../classTensor.html#a4fb7542a9e054e86ff03899cc8b52290',1,'Tensor']]],
  ['representation',['Representation',['../classOperator.html#a0311bff179d27e8e5abb01e9e26f4f56',1,'Operator::Representation()'],['../classOperator2D.html#a026c1c0c62a7e1f72305f35a24d7a0de',1,'Operator2D::Representation()']]]
];
