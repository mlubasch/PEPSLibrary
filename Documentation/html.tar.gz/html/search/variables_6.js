var searchData=
[
  ['shape',['Shape',['../classTensor.html#a602af649cc22d0adcf990c24544d2816',1,'Tensor']]],
  ['size',['size',['../classTensor.html#a5c0c3672ef6b5e2826336b079ac5633b',1,'Tensor']]]
];
