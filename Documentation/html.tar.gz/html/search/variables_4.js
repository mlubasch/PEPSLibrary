var searchData=
[
  ['parameters',['Parameters',['../classHamiltonian.html#a26ed1edf057faea70745357ea4845109',1,'Hamiltonian::Parameters()'],['../classHamiltonian2D.html#ad1e50d4edf2fe92d684d228c824d5e3e',1,'Hamiltonian2D::Parameters()']]]
];
